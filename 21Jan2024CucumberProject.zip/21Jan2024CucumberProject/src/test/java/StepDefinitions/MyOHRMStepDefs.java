package StepDefinitions;

import org.openqa.selenium.By;

import TestRunnerPack.TestRunner;
import io.cucumber.java.en.*;

public class MyOHRMStepDefs {
	
	@Given("^I navigate to \"(.*)\" browser and launch URL \"(.*)\"$")
	public void i_navigate_to_browser_and_launch_URL(String browser, String URL) throws Throwable
	{
		TestRunner.driver.navigate().to(URL);
		System.out.println("browser used is "+browser);
		Thread.sleep(2000);
	}
	
	@When("^I enter the username in uname field as \"(.*)\"$")
	public void i_enter_the_username_in_uname_fieldas(String username) throws Throwable
	{
		TestRunner.driver.findElement(By.name("username")).sendKeys(username);
		Thread.sleep(2000);
	}
	
	@When("^I enter the password in pswd field as \"(.*)\"$")
	public void i_enter_the_password_in_pswd_fieldas(String password) throws Throwable
	{
		TestRunner.driver.findElement(By.name("password")).sendKeys(password);
		Thread.sleep(2000);
	}
	
	// password

}
